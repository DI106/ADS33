class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


def invertTree(root):
    if not root:
        return None

    root.left, root.right = root.right, root.left

    invertTree(root.left)
    invertTree(root.right)

    return root
my_root = TreeNode(3)
my_root.left = TreeNode(9)
my_root.right = TreeNode(20)
my_root.right.left = TreeNode(15)
my_root.right.right = TreeNode(7)

print(invertTree(my_root))