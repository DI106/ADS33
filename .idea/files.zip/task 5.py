from collections import deque

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def levelOrder(root):
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        level_size = len(queue)
        current_level = []

        for _ in range(level_size):
            node = queue.popleft()
            current_level.append(node.val)

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.append(current_level)
    return result

my_root = TreeNode(3)
my_root.left = TreeNode(9)
my_root.right = TreeNode(20)
my_root.right.left = TreeNode(15)
my_root.right.right = TreeNode(7)

print(levelOrder(my_root))