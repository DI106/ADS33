def quickSort(nums):
    if len(nums) <= 1:
        return nums

    pivot = nums[len(nums) // 2]
    left = [x for x in nums if x < pivot]
    middle = [x for x in nums if x == pivot]
    right = [x for x in nums if x > pivot]

    return quickSort(left) + middle + quickSort(right)


data = [64, 34, 25, 12, 22, 11, 90]
print("Quick Sort:", quickSort(data))