class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def isSameTree(p, q):
    if not p and not q:
        return True
    if not p or not q or p.val != q.val:
        return False

    return isSameTree(p.left, q.left) and isSameTree(p.right, q.right)

my_root = TreeNode(3)
my_root.left = TreeNode(9)
my_root.right = TreeNode(20, TreeNode(15), TreeNode(7))

another_root = TreeNode(3, TreeNode(9), TreeNode(20, TreeNode(15), TreeNode(7)))

print(f"{isSameTree(my_root, another_root)}")