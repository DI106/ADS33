def isHappy(n):
    visited = set()
    while n != 1:
        if n in visited: return False
        visited.add(n)

        n = sum(int(i) ** 2 for i in str(n))
    return True

print(isHappy(19))