def twoSum(nums, target):
    hashmap = {}
    for i, n in enumerate(nums):
        complement = target - n
        if complement in hashmap:
            return [hashmap[complement], i]
        hashmap[n] = i

print(twoSum([2, 7, 11, 15], 9))
