def isIsomorphic(s, t):
    mapST, mapTS = {}, {}
    for charS, charT in zip(s, t):

        if charS in mapST and mapST[charS] != charT:
            return False

        if charT in mapTS and mapTS[charT] != charS:
            return False

        mapST[charS] = charT
        mapTS[charT] = charS

    return True

print(isIsomorphic("egg", "add"))