import collections

def firstUniqChar(s):
    count = collections.Counter(s)

    for i in range(len(s)):
        if count[s[i]] == 1:
            return i
    return -1

print(firstUniqChar("leetcode"))