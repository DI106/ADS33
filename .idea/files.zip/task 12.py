def heapify(nums, n, i):
    largest = i
    l = 2 * i + 1
    r = 2 * i + 2

    if l < n and nums[l] > nums[largest]: largest = l
    if r < n and nums[r] > nums[largest]: largest = r

    if largest != i:
        nums[i], nums[largest] = nums[largest], nums[i]
        heapify(nums, n, largest)

def heapSort(nums):
    arr = nums[:]
    n = len(arr)
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]
        heapify(arr, i, 0)
    return arr

data = [64, 34, 25, 12, 22, 11, 90]
print("Heap Sort:", heapSort(data))