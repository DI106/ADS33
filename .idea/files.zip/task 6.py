from collections import deque

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def maxDepth(root):
    if not root:
        return 0
    return 1 + max(maxDepth(root.left), maxDepth(root.right))

my_root = TreeNode(3)
my_root.left = TreeNode(9)
my_root.right = TreeNode(20)
my_root.right.left = TreeNode(15)
my_root.right.right = TreeNode(7)

print(maxDepth(my_root))